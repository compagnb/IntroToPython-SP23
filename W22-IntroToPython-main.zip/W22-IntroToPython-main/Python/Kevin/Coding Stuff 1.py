## Week 1
## Print is a function that allows us to print in the console
## It must have an open and a close parenthesis

print("Jayden's Birthday is today!")
print(1+1)
## To add we use +
## To subtract we use -
## To multiply we use *
## To divide we use /

## types of information
## integers are whole numbers
## floats are numbers that are inbetween two whole numbers, such as fractions and decimals

## Variables are place holders

name = "Barb"
age = input("what is your age? ")
print(name + "'s birthday is today! " + name + " just turned " + str(age) + "! ")
