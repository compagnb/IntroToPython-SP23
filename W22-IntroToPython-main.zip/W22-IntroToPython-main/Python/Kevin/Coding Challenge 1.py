name = input("what is your name? ")
age = input("how old will you be on your birthday? ")
bday = input("speaking of which, when is your birthday? ")
print("Okay, so you're " + name + ", your birthday is " + str(bday) + ", and on your next birthday you will be " + str(age) + " years old! Yay!")
