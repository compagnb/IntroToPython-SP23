## turtle fun
## create a bulls eye with turtle
import turtle

t=turtle.Turtle()

for x in range(0,100):
    print(x)
    t.forward(10+x)
    t.right(30*x)
    
