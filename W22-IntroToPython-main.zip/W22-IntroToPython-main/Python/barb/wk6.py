## Turtles!

## This imports a library or module.
## Without doing this we cannot use it in our code!
import turtle

##Creating an instance of the turtle class
mike = turtle.Turtle()
mike.shape('turtle')
mike.color('orange')
leo = turtle.Turtle()
leo.shape('turtle')
leo.color('blue')

## Draw a square
leo.forward(100)
leo.left(90)
leo.forward(100)
leo.left(90)
leo.forward(100)
leo.left(90)
leo.forward(100)
