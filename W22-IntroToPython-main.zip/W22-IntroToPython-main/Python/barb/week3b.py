trickOrTreatBag = ['twix', 'chocolate covered no', 'family sized bag of chips', 'chocolate covered chucky bar']

print("I want to eat " + trickOrTreatBag[2] + " first.")

trickOrTreatBag.remove[1]

