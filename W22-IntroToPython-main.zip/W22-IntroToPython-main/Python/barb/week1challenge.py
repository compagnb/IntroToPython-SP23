## Week 1 Challenge

## Write a program to ask the user their name, age & birthday
## Have the statment print out
## Hi my name is --- and on --- i will be ---.
