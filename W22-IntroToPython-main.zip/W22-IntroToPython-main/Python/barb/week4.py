## Week 4
## CONDITIONALS!!!
## IF this then that

students = ['Dallis', 'Jayden', 'Terrence', 'Xander', 'Kevin', 'Skylar', 'Barb']
theBest = students[6]

answer = input("Who is the best in this class?")

if(answer == theBest):
    print("You are right! " +theBest+ " is the best!")
else:
    print("Sorry, "+ answer + " is incorrect!")
    


