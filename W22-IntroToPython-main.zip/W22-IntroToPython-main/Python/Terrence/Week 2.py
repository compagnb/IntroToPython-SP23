## Week 2
## Scary Mad Libs
## print story with user input
## variable rules
## Cannot start with caps or numbers
## Cannot contain special characters like ?!@#$%^&*() or spaces instead use body-part or bodyPart.
## Cannot have same name
## 

noun = input("Please enter a noun")
adj = input("Please enter a adjective")
verbing = input("Please enter a verb ending in ing")
adj2 = input("Please enter a adjective")
verb = input("Please enter a verb")
nounBodyPart = input("Please enter a body part")
verb2 = input("Please enter a verb")
verb3 = input("Please enter a verb")
adj3 = input("Please enter a adjective")
pluralNounBodyPart = input("Please enter a body part in the plural form")
adjColor = input("Please enter a color")
pluralNounAnimal = input("Please enter a animal in the plural form")
adjColor2 = input("Please enter a color")
beverage = input("Please enter a beverage")
adj4 = input("Please enter a adjective")
pluralNounBodyPart2 = input("Please enter a body part in the plural form")


story = "Did you know there's going to be a "+noun+" at the "+adj+" School for Zombies? There will be a DJ "+verbing+" "+adj2+" songs to "+verb+" to. Popular zombie dances include The "+nounBodyPart+" "+verb2+" and The "+verb3+". The school gym is decorated with "+adj3+" "+pluralNounBodyPart+" and "+adjColor+" "+pluralNounAnimal+" heads. In between songs, there are treats like "+adjColor2" "+beverage+" and "+adj4+" "+pluralNounBodyPart+"."
print(story)




