## Week 4
##

students = ['Dallis', 'Jayden', 'Terrence', 'Xander', 'Kevin', 'Skylar', 'Barb']
theBest= (students[2]) 

answer = input("Who is the best in this class?")

if(answer == theBest):
    print("You aren't left becuase " +theBest+ " is the best!")
else:
    print("Sorry, "+ answer + " is a failure or you are a failure and you typed it in wrong.")
numberAnswer = 5
numberQuestion = input(
