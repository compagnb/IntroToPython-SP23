## Week 3
## Lists - can contain a bunch of variables
## ints, floats, chars and strings
## 


doYouWantToContinue=True

trickOrTreatBag = []

while True:
    treat = input("Trick or treat. Gimme something good to eat")
    trickOrTreatBag.append(treat)
    print(trickOrTreatBag)
    #doYouWantToContiue = input("Type True to continue and False to stop.")
