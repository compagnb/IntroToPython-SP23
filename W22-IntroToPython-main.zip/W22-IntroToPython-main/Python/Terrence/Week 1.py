## Week 1
## print is a function that allows us to print in the console
## it must have an open and a close ()
## to add use +
## to subtract we use -
## to multiply we use *
## to divide we use /

## types of info
## integers are whole numbers
## floats are fractions/decimals
## chars are single letters
## strings are always surrounded by quotations(single or double)

## variable is a place holder 


name = "barb"
age = input("what is your age?") 
print(name + " b-day is today!" + name + " just turned " + str(age) + ". ")
