Python 2.7.16 (v2.7.16:413a49145e, Mar  4 2019, 01:37:19) [MSC v.1500 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> 
======================= RESTART: C:/Python27/week1.py =======================
>>> 
======================= RESTART: C:/Python27/week1.py =======================
>>> 
======================= RESTART: C:/Python27/week1.py =======================
Bananas are very good i ate 12 of them
>>> 
===================== RESTART: J:/Python/Xander/week1.py =====================
Jaydens B-day is today! he just turned 12.
>>> 
===================== RESTART: J:/Python/Xander/week1.py =====================
what is your age?
===================== RESTART: J:/Python/Xander/week1.py =====================
what is your age?
===================== RESTART: J:/Python/Xander/week1.py =====================
what is your age?
===================== RESTART: J:/Python/Xander/week1.py =====================
what is your age?
===================== RESTART: J:/Python/Xander/week1.py =====================
what is your age?
===================== RESTART: J:/Python/Xander/week1.py =====================
what is your age?
===================== RESTART: J:/Python/Xander/week1.py =====================
what is your age?
===================== RESTART: J:/Python/Xander/week1.py =====================
what is your age?
