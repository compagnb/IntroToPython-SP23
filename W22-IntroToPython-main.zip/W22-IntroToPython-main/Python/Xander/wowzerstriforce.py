
import turtle
leo = turtle.Turtle()
leo.shape('turtle')
leo.color('yellow')

leo.forward(80)
leo.left(120)
leo.forward(80)
leo.left(120)
leo.forward(80)
