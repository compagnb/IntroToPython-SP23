## week 2
## scary madlibs
## print story and with user input
##
##variable rules
## cannot start with capital letters
## cannot start with numbers
##cannot contain special characters like ?!.
##cannot have spaces in them- use body-part bodyPart
## they cannot have the same name as other variable

name = input("please enter a name")
adj = input("please enter an adjective")
adj2 = input("please enter an adjective")
name2 = input("please enter a name")
adj3 = input("please emter an adjective")
name3 = input("please enter a name")
verbing = input("please enter a verb ending in ing")
game = input("please enter a game console")
name4 = input("please enter a name")
name5 = input("please enter a name")
sound = input("please enter a name")
videoGame = input("please enter a game")

story = "There once was a boy who had a doll. the doll was called "+ name +".the "+ adjective + "doll would always seem to move places when the boy went to sleep. but one night, the father wanted to get to the bottom of this. he installed cameras in every room.
"it seemed normal at first, but then he discovered the "+ adjective2 + "truth." +name2+ "WAS DELETING SAVE FILES! the boy was "+adjective3 + "when he heard the news. they figured name was actually listening, so they didnt talk that
"much. the boy was " + verbing +" with the doll, as normal, until he had to go to bed. that night, he snuck his "+ game+ "into his bed, forgetting what" + name4 + "did. so when he fell asleep,"+ name5 + "had sensed that there was another
"console present. he ran to the room, got up to the knife block, and up thestairs he went. the childs door made a slight" + sound +" noise, and the next thing he knew, his " + videogame +account +" was gone. and so was his doll."
