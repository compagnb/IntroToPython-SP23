trickOrTreatBag = ['twix',] ('chocolate covered no", "family sized bag of chips", "chocolate covered chucky doll")

print("i want to eat " +trickOrTreatBag[] + "first")
