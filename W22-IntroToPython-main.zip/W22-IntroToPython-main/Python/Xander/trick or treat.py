## week 3
## lists-can contain a bunch of variables
## ints, floats, chars, strings


numOfHouses=0

doYouWantToContinue=True

trickOrTreatBag = ['twix',] "chocolate covered no," "family sized bag of chips", "chocolate covered chucky doll")

while num0fHouses <= 10:
    treat = input("Trick or Treat give me something good to eat!")
    trickOrTreatBag.append(treat)
    print(trickOrTreatBag)
    #doYouWantToContinue = input("Type True to continue and False to stop.")
    numOfHouses = numOfHouses +1
