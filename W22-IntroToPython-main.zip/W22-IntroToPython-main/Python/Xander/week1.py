# week 1
## print is a function that allows us to print in a console
## it must have an open and close ()

## basic operations
## to add we use +
## to subtract we use -
## to multiply we use *
## to divide we use /

## types of information
## integers are whole numbers
## floats are decimals
## chars are single letters
## strings are always surrounded by quotations (single or double)

## variable is a placeholder

name = "Xander the Commander"
age = input ("what is your age?")
print(name+ "'s B-day is today! " + name + " just turned" + str(age) + 
