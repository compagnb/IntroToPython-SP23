## turtle fun
## create a bulls eye with turtle
import turtle

t=turtle.Turtle()

for x in range
