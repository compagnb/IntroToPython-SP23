## Week 3
## Lists - can contan a bunch of variables
## ints, floats, chars, strings

doYouWantToContinue=True

trickortreatbag = []

while True:
    treat = input("Trick or treat! Give me something good to eat.")
    trickortreatbag.append(treat)
    print (trickortreatbag)
#doYouWantToContinue = ("Type True to contine and False to stop.")
