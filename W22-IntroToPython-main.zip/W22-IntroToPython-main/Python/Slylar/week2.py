## Week 2
## Scary MadLibs
## print story and with user input
##
## Variuable rules
## Cannot start with capital letters
## Cannot start with numbers
## Cannot contain special characters
## Cannot have spaces in them
## They cannot have the same name as other variables

noun = input("Please eneter a noun.")
adj = input("Please eneter an adjective.")
verbing = input("Enter a verb using ing.")
adj2 = input("Enter an adjective.")
verb = input("Enter a verb.")
bodypart = input("Enter a body part.")
verb2 = input("Enter a verb.")
verb3 = input("Enter a verb.")
adj3 = input("Enter an adjective.")
bodypart2 = input("Enter a body part.")
color = input("Enter a color.")
animal = input("Enter an animal.")

story = "there was girl who was scared of spiders and when she went to bed that night a long big spider crwled into her mouth and layed eggs the next day she felt a little weird and BOOM the spider crwled out and then she had baby spiders crwling inside of her and crawling out of her mouth, the end."
