## week 4
## CONDITIONALS!!!
## If this then that

students=['Dallis','Jayden', 'Terrence', 'xander', 'Kevin', 'Skylar', 'Barb']
theBest=students[5]

answer = input("Who is the best in this class?")

if (answer == theBest) :
    print("You are right! " +thebest+ " is the best!")
else:
        print("Sorry, "+answer+" is incorrect!")
