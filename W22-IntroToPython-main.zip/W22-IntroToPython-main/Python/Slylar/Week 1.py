## Week 1
## print is a function that allows us to print in the console
## it must have an open and a close ()

## basic operations
## to add we can use +
## to subtract we can use -
## to multiply we use *
## to divide we use /

## types of information
## integers are whole numbers
## float are decimals
## chars are single letters
## strings are always surrounded by quotations (single or double)

## variable is a place holder

name = "Barb"
age = input("1What is your age")
print(name + " b-day is today!" + name + " just turned " + str(age) + ". ")
