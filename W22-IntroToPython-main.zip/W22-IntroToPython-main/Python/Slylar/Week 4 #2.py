#Guessing Game

theNumber=5

input( "Guess a number between 0-10?")

print ("The number is[5]!")
