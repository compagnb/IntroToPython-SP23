## week 2
## Scary Madlibs
## print story and with user input
##
## Variable Rules
## Cannot start with capital letters
## Cannot start with numbers
## Cannot contain special character like ?!.
## Cannot have spaces in them - use body-part bodypart
## cannot have the same name as other variables

noun = input("Please enter a noun,")
adj = input("Please enter an adjective")
verbing = input("Enter a verb using ing")
adj2 = input("Please enter an adjective")

storyI = "I was talking to my wife she had said he had to go visit her"+noun+" and as she left ijust stayed sitting sipping on my"+adj+" coffebut as the time went by 1 hour 2 hours 3 hours 4 hours 5 hours the clockjust kept"+ing+" and i was wondering why she had not been back i tried callingher but no awnser i waited a day but she never came back so i decided toleave and go to her family as i arrived i had a"+adj+" feeling that i shouldnot be here but i had to figure to know why my wife was taking this long iknocked on the door but no awnser i tried to open the door but i needed akey so as i walked to looking for a key i finally found one under a rock soi went back and open the door when i opened the door the whole house was emptybut i felt like there was more to this house so i walked around and aroundlooking for somthing then i saw a closet then i saw a ladder going downsomewhere with my curosity bugging at me to go down i went down then i foundmyself in a cave with jail doors and such i walked by and heard my wifescream i rain over there and found a video and then i saw her saying Ethan if you find this ge tout of here my family is taking me away andis doing expirements on me i cant say much but all i can say is leavebecause when you find me i wont be the same again all i can think aboutafter hearing that was getting out of there i di dnot want to seethis place anymore but i had to save my wife so i left and got prepared." 
ptint(storyI)
