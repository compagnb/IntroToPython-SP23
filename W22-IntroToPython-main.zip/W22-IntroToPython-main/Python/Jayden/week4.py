## Week 4
## CONDITIONALS!!!
## IF this then that

students = 'Dallis', 'Jesus Christ', 'Terrence', 'Xander', 'Kevin', 'Skylar', 'barb',
theBest= students[1]

awnser = input("who is the best in this class?")

if (awnser == theBest):
    print("you are right! " +theBest+ "is the best!")
else:
    print("sorry, "+ awnser + " is incorrect! ")
