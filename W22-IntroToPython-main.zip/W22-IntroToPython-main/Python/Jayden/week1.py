## Week 1
## print is a function that allows u sto print in the console
## it must have an open and a close ()

## to add we can use +
## to subtract we can use -
## to multiply we use *
## to divide we use /

## types of information
## integers are whole numbers
## floats are decimals
## chars are single letters
## strings are always surrounded by quotation (single or double)

## variable is a place holder
name = "Barb"
age = input("what is your age?")
print(name + "'s b-day is today! " + name + " He just turned " + str(age) + ". ")
