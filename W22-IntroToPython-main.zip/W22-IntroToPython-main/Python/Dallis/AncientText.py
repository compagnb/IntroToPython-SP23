print ("First, a cloud of bats will cover the sky. Then, people will chant the name of the King of Undead Digimon. And when the clock strikes the Number of the Beast,the King of Undead Digimon will appear in his true form of the beast.When angels fire arrows of Hope and Light at the dearest loved one of those whom they are meant to protect, a miracle will occur.")
print (" - Digimon Adventure")
