name = input ("What is your name?")
age = input ("What is your age?")
print (name + "'s b-day is today!" + name + " just turned" + age+".")

