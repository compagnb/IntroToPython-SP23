import turtle
mike = turtle.Turtle()
mike.shape("turtle")
mike.color("orange")
for x in range(0,4):
    mike.forward(100)
    mike.left(90)
leo = turtle.Turtle()
leo.shape("turtle")
leo.color("blue")
for x in range(0,4):
    leo.backward(100)
    leo.left(90)
raff = turtle.Turtle()
raff.shape("turtle")
raff.color("red")
for x in range(0,4):
    raff.backward(100)
    raff.right(90)
don = turtle.Turtle()
don.shape("turtle")
don.color("purple")
for x in range(0,4):
    don.forward(100)
    don.right(90)
