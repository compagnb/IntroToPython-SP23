cont=""
story = "On a dark, cold night..." +cont
while True: 
    print (story)
    cont = input("Tell me more!")
    story = story + cont
