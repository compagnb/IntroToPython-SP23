bodyPart = input ("Name a body part.")
game = input ("What is your favorite video game?")
story = "I am XO,the ghost griefer... I see that you like " + game + "I also know you are addicted to this so called 'best game ever'. Well, your future experiences will not be  good. You will fail and fail and fail and fail and fail until your " + bodyPart + "falls off! Too late! Your team lost and you missed a game!"
print (story)
