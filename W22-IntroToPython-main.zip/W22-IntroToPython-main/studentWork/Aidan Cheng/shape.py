import turtle
sides = 0
leo = turtle.Turtle()
leo.shape("turtle")

leo.forward(100)
leo.left(90)
leo.backward(100)
leo.right(90)

leo.penup()
leo.goto(100, 100)
leo.pendown()

#while True: # this an infinite loop it will never stop!
while sides < 4:
     leo.forward(100)
     leo.right(90)
     sides=sides+1
     import turtle

leo = turtle.Turtle()
leo.shape("turtle")

leo.backward(100)
leo.right(90)
leo.forward(100)
leo.left(90)

leo.penup()
leo.goto(100, 100)
leo.pendown()

#while True: # this an infinite loop it will never stop!
while sides < 4:
     leo.forward(100)
     leo.right(90)
     sides=sides+1
    
