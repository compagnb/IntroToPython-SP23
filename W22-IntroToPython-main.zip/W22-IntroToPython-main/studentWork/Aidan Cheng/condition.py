#Conditionals

#if(condition):
# do this
# else:
#  do that

userInput = input("guess my name")
if(userInput == "Aidan"):
  print("Correct")
elif(userInput == "Aiden):
  print("Close")
else:
  print("sorry")
     



