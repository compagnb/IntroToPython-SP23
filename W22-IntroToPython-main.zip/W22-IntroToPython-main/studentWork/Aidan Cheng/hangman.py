#hangman
#what do we need?
# word (and the letters that make it up)
# amount of tries (6)
