#Variables!!!
#Cant have in a varible name:
#spaces - use camelCase or under_scores
#capital letters- these are resevered gor other functions

name="Aidan" #this is a string
age = 11 #this is an integer (whole number)
pie = 3.14 # this is called a float (decimal)
favPie = "Cat"

#Strings
#must be surrounded by quotes
#they both need to be either " or '
# if you have a contraction surround it in"
#srings and ints can't be added - to add
#- to add an int to a string we have to mask the int using str()
hereFirst = "Bryce & Kurt"
said = "said 'We won't have any vocabulary today'"
space = ""
print(hereFirst + space + said)
name = "Aidan"
age = 11
hi = "Hi, my name is"
hello = "am my age is"
sentence = hi + name + hello + str(age)
aa
print(sentence)
name + age







