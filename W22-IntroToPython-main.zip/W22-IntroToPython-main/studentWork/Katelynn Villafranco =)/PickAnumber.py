import random

number = random.randint(0,0)
correctAnswer = False
userInput = int(input("pick a number"))

while correctAnswer === False:
    if(userInput == numb):
        print("You Win")
        correctAnswer = True
        else:
            print("sorry you are wrong the correct number was " + str(numb))
            userinput = int(input("pick a number"))
            
