#list/array

myList = 1, 2, 3, 4, 5, 6, 7, 8, 9, 10
myOtherList = "a", "b", "c"
anotherList = "a", "b", "c", 1, 2, 3

print (myList[4])
print (anotherList[1])

shoppingList = ["water" + "kiwwi" + "cerial"]
shoppingList.append ("McDonalds")
#shoppingList.append("McDonalds")

addToList = input ("what do you need to added.")
shoppingList.append (addToList)


    

