import turtle
mike = turtle.Turtle()
mike.color ("orange")
raph = turtle.Turtle()
raph.color("red")
dony = turtle.Turtle()
dony.color("purple")
leo = turtle.Turtle()
leo.color("blue")
leo.shape ("turtle")
sides = 0

mike.penup()
mike.goto(-100,100)
mike.pendown()

leo.penup()
leo.goto(100, 100)
leo.pendown()
           
           
