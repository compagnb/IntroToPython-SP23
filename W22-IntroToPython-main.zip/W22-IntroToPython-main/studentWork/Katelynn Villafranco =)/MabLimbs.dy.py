#Madlib Game
#input() - take input from the user

number1  = input("Please enter a number.")
#print(number1)
noun1 = input ("Please enter a noun.")
#print (noun1)
verb1 = input ("Please enter a verb.")
#print(verb1)
adjl = input ("Please enter a adjective.")
#print (adj1)
number2 = input ("Please enter a number.")
#print(number2)
place1 = input ("Please enter a place.")
#print(place1)
FirstName1 = input ("Please enter a name.")
#print(FirstName1)
FirstName2 = input ("Please enter a name.")
#print(FirstName2)
verbEd1 = input ("Please enter a verb-ed.")
#print(verbEd1)
noun2 = input ("Please enter a noun.")
#print(noun2)
adj2 = input ("Please enter a adjective.")
#print(adj2)
adje3 = input ("Please enter a adjective.")
#print(adj3)
verbEd2 = input ("Please enter a verb-ed.")
#print(verbEd2)
verbEd3 = input ("Please enter a verb-ed.")
#print(verbEd3)
noun3 = input ("Please enter a noun.")
#print(noun3)
verbEd4 = input ("Please enter a verb-ed.")
#print(verbEd4)
pluralNoun1 = input ("Please enter a plural noun.")
#print(pluralNoun1)
verb2 = input ("Please enter a verb.")
#print(verb2)
adverb1 = input ("Please enter a adverb.")
#print(adverb1)
number2 = input ("Please enter a number.")
#print(number2)

madlib = "first part" + number1 + "second part" + noun1 + "third part" + verb1 + "fourth part" + adj1 + "fifth part" + numbr2 + "sixth part" + place1 + "seventh part" + FirstName1 + "eighth part" + FirstName2 + "ninth part" + verbEd1 + "tenth part" + noun2 + "eleventh part" + adje2 + "twelvth part" + adje3 + "thirteenth part" + verbEd2 + "fourteenth part" + verbEd3 + "fifteenth part" + noun3 + "sixteenth part" + verbEd4 + "seventeenth part" + pluralNoun1 + "eighteenth part" + verb2 + "nineteenth part" + adverb1 + "twentyeth part" + number2\












