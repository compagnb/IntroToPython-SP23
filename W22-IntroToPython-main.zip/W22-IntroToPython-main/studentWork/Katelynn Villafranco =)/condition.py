#Conditionals

#if(condition):
# do this
# else:
#   do that

userInput = input("guess my name")
if(userInput == "Katelynn"):
    print("Correct")
elif(userInput == "Kate"):
    print("Close")
else:
  print("sorry")
