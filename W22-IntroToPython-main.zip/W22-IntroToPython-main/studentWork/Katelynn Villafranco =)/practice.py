Python 2.7.16 (v2.7.16:413a49145e, Mar  4 2019, 01:37:19) [MSC v.1500 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> hi = Hello There,
SyntaxError: invalid syntax
>>> name = Katelynn

Traceback (most recent call last):
  File "<pyshell#1>", line 1, in <module>
    name = Katelynn
NameError: name 'Katelynn' is not defined
>>> print ("hi+name")
hi+name
>>> name="Katelynn"
>>> hello="Hi There"
>>> print ("name+hello")
name+hello
>>> 1 + 1
2
>>> 3 x 2
SyntaxError: invalid syntax
>>> 20 * 5
100
>>> 24 / 6
4
>>> 7 - 3
4
>>> name="I am"
>>> hi="A princess UnU"
>>> print ("name+hi")
name+hi
>>> 
>>> name = "I am"
>>> hi = "A cute, adorable, cat UwU"
>>> print ("name + hi")
name + hi
>>> name * age

Traceback (most recent call last):
  File "<pyshell#18>", line 1, in <module>
    name * age
NameError: name 'age' is not defined
>>> 
