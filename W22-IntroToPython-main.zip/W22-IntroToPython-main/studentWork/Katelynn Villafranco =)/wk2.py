#Variables!!!
#Cant have in a variable name:
#spaces - use camelCase of under_scores
#capital letters - these are reserved for other functions

name = "Katelynn" #this is a string
age = 11 #this is an integer (whole number)
pi = 3.14 #this is called float (decimal)
favPie = "Apple"

#Strings
#must be surrounded by quotes
#they both need to be either " or '
#if you have a contraction surrounded in it "\
# - to add an into to a string we have mask the int using str()
hereFirst = "Bryce & Kurt"
said = "said 'We won't have any vocabulary today'"
space = " "
print (hereFirst + space + said)

name = "Katelynn"
age = 11
hi = "Hi, my name is "
ageIs = ", and my age is "
scentence = hi + name + ageIs + str(age)
print (sentence)
name * age

