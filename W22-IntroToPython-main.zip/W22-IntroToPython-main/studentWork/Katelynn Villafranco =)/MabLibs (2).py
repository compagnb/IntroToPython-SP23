#Madlib Game
#input() - take input from the user

number1  = input("Please enter a number.")
noun1 = input ("Please enter a noun.")
verble1 = input ("Please enter a verb.")
adjl = input ("Please enter a adjective.")
number2 = input ("Please enter a number.")
place1 = input ("Please enter a place.")
FirstName1 = input ("Please enter a name.")
FirstName2 = input ("Please enter a name.")
verbEd1 = input ("Please enter a verb-ed.")
noun2 = input ("Please enter a noun.")
adj2 = input ("Please enter a adjective.")
adje3 = input ("Please enter a adjective.")
verbEd2 = input ("Please enter a verb-ed.")
verbEd3 = input ("Please enter a verb-ed.")
noun3 = input ("Please enter a noun.")
verbEd4 = input ("Please enter a verb-ed.")
pluralNoun1 = input ("Please enter a plural noun.")
verb2 = input ("Please enter a verb.")
adverb1 = input ("Please enter a adverb.")
number2 = input ("Please enter a number.")











