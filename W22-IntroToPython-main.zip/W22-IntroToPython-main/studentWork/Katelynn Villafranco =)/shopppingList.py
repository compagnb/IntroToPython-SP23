Python 2.7.15 (v2.7.15:ca079a3ea3, Apr 30 2018, 16:22:17) [MSC v.1500 32 bit (Intel)] on win32
Type "copyright", "credits" or "license()" for more information.
>>> 
========= RESTART: J:/W22-Python-AM/Katelynn Villafranco UnU/wk3.py =========
(1, 2, 3, 4, 5, 6, 7, 8, 9, 10)
>>> 
========= RESTART: J:/W22-Python-AM/Katelynn Villafranco UnU/wk3.py =========
5
>>> 
========= RESTART: J:/W22-Python-AM/Katelynn Villafranco UnU/wk3.py =========
5
c
>>> 
========= RESTART: J:/W22-Python-AM/Katelynn Villafranco UnU/wk3.py =========
5
c
>>> 
========= RESTART: J:/W22-Python-AM/Katelynn Villafranco UnU/wk3.py =========
5
b
>>> 
========= RESTART: J:/W22-Python-AM/Katelynn Villafranco UnU/wk3.py =========
5
b

Traceback (most recent call last):
  File "J:/W22-Python-AM/Katelynn Villafranco UnU/wk3.py", line 11, in <module>
    shoppingList.append("McDonalds")
AttributeError: 'str' object has no attribute 'append'
>>> 
========= RESTART: J:/W22-Python-AM/Katelynn Villafranco UnU/wk3.py =========
5
b
['waterkiwwicerial']
>>> 
========= RESTART: J:/W22-Python-AM/Katelynn Villafranco UnU/wk3.py =========
5
b
what do you need to add to the shopping list
