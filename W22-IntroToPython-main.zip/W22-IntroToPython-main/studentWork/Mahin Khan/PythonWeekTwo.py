#Variables!!!
#Cant have un a variable name:
#spaces - use camelCase or under_scores/
#capital letters - these are reserved for other functions

name = 'Mahin' #this is a string
age = ' 12' #this is an integer (whole number)
pie = 3.14 #this is called a float (decimal)
favPie = 'pumkin'

#Strings
#must be surrounded by quotes
#they both need to be either " or '
#if you have a contraction surround it in "
#strings and ints can't be add
#- to add an int to a string we have to mask the int using str()
hereFirst = 'Bryce & Kurt'
said = "said We won't have any vocabulary today'"
space = " "
nameState = 'Hi! My name is '

ageSentenceStarter = ' I am '

newAge = ' andmyage is'



dupeAge = ' years old.'
hi = "hi my name is"
isAge = ", and my age is "

sentence = hi + name + isAge + str(age)

name * age
