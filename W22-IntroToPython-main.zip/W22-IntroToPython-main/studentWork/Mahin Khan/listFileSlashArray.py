#lists/array

myList = 1, 2, 3, 4, 5, 6, 7, 8, 9, 10
myOtherList = 'a', 'b', 'c'
anotherList = 'a', 'b', 'c', 1, 2, 3,

print(myList[7])
print(anotherList[1])

shoppingList = ['milk', 'eggs', 'Lengend of Zelda: Breath of The Wild 2']
shoppingList.append("Botw 2 DLC")

addToList = input('what needs to be added.') 
shoppingList.append(addToList)
shoppingList.remove("eggs")

print(shoppingList)

#Conditionals
                  
#if(condition):
#  do this
#  else:
#    do that

userInput = ('guess my name')
if(userInput == 'Barb'):
  print('Correct')
elif(userInput == "Mahdi"):
  print('Close')
else:

  print('sorry')                  














                  
