#Madlib Game
#input() - take input from the

number = 20
number = 22

number1 = input("Please enter a number.")
#print(number1)
noun1 = input"garbage"
verb1 = input"Please enter a verb."
adj1 = input"cringy"
number2 = input"Please enter a number."
place1 = input"Please enter a"
firstName1 = input"Please enter a name."
firstName2 = input"Please enter a name."
verbEd1 = ""
noun2 = input"hi"
adj2 = input"massive"
adj3 = "awesome"
adj4 = input"lots of"
verbEd2 = ""
verbEd3 = ""
noun3 = input"goodbye"
noun4 = input"dirtbag"
verbEd4 = ""
pluralNoun1 = input"garbage"
pluralNoun2 = input"Hell"
pluralNoun3 = input"snickerdoodles"
pluralNoun4 = input"dirt"
pluralNoun5 = input"bags"
verb2 = ""
adverb1 = ""
number2 = ""
