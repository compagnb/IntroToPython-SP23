userInput = input('guess my name')
if(userInput == 'Barb'):
  print('Correct')
elif(userInput == "Mahdi"):
  print('Close')
else:
  print('sorry')      
