#Variables!!!
#Cant have in varisbles name:
#sapces - use camelCase or under_scores
#capital letters - these sare reserved for other functions.

name= "Kurt"  #this is a string.
age = 10 #this is an integer (Whole number)
pi = 3.14 #this is called floats (decimal)
favPie = "Apple"


#Strings
# must be surrounded by quotes.
#they both need to be either "or"
#if you have a contraction surround it in "

hereFirst = "Kurt & Bryce"
said = "said We won't have any vocabulary today'"
space = " "
#print(hereFirst + space + said)

#Challenge Hi my name is sentence.
hi = "Hi my name is "
ageIs = ", and my age is "
age = 10
name = "Kurt"
sentence 'hi + name + ageIs + str(age)
print
(sentence)
