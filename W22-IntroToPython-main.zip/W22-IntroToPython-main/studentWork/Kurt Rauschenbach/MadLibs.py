
#Madlib Game
#input () - take input from the user.


number1 = input("Please enter a number.")
noun1 = input ("Please enter a plural noun.")
verb1 = input ("Please enter a verb.")
adjective1 = input ("Please enter a adjective.")
number2 = input("Please enter a number.")
noun2 = input ("Please enter a place.")
name1 = input ("Please enter a Name.")
name2 = input ("Please enter a Name.")
verb2 = input ("Please enetr a verb with ED.")
noun3 = input ("Please enter a noun.")
verb3 = input ("Please enetr a verb with ED.")
number3= input("Please enter a number.")
adjective2 = input ("Please enter a adjective.")
adjective3 =  input ("Please enter a adjective.")
verb4 = input ("Please enetr a verb with ED.")
verb5 = input ("Please enetr a verb with ED.")
noun4 = input ("Please enter a noun")
verb6 = input ("Please enetr a verb with ED.")
noun5 = input ("Please enter a noun.")
verb7 = input ("Please enter an adverb.")
verb8 = input ("Please enter a verb.")
number4 = input("Please enter a number.")

madlibs = "On July" + number1 + "1969, two American" + noun1 + "were the first to" + verb1 + "on the moon. This" + adjective1 + "trip took" + nuber2 + "days to reach the moon from"
+ noun2 + "as" + name1 + "Armstrong and" + name2 + "Aldrin" + verb2 + "onto the" + noun3 + "of the the moon, Armstong" + verb3 + "the famous words, Thats" + number3 + adjective2
+ "step for a man, one" + adjective3 + "leap for mankind. Soon after, Aldrin" + verb4 + " onto the moon and together they" + verb5 + " a U.S." + noun4 + "on the suface to" + verb6
+ noun5 + " from the moons surface to" + verb7 + "back to Earth and" + verb8 + "returned home" + number4 + " days later."
print "madlibs"


