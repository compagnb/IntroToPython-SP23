#Madlib Game
#variable = input("question here") - take input from the user
#https://swantonpubliclibrary.org/sites/default/files/mad%20lib%20moon.jpg

number1 = input("Please enter a number.")
#print(number1)
noun1 = input("Please enter a noun.")
verb1 = input("Please enter a verb.")
adj1 = input("Please enter an adjective.")
number2 = input("Please enter a number.")
place1 = input("Please enter a place.")
firstName1 = input("Please enter a name.")
firstName2 = input("Please enter a name.")
verbEd1 = ""
noun2 = ""
adj2 = ""
adj3 = ""
verbEd2 = ""
verbEd3 = ""
noun3 = ""
verbEd4 = ""
pluralNoun1 = ""
verb2 = ""
adverb1 = ""
number2 = ""






