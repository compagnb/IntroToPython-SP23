name = "Barb"
hello = "Hi there "
numb1 = 10
numb2 = 5
numberOfDirtCube = 100
number_of_dirt_cube = 100

#addition operator
print(hello + name)
#subtraction operator
print(numb1 - numb2)
#multiplcation operator
print(numb1 * numb2)
#division operator
print(numb1 / numb2 )




cubesADay = 10
daysInAYear = 365
lostCubes = 3
weeksInAYear = 52

print(cubesADay * daysInAYear - lostCubes * weeksInAYear)


















