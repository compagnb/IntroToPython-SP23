#Variables!!!
#Cant have in a variable name:
#spaces - use camelCase or under_scores\
#capital letters - these are reserved for other functions

name = "Barb" #this is a string
age = 23 #this is an integer (whole number)
pi = 3.14 #this is called floats (decimal)
favPie = "Banana"

#Strings
#must be surrounded by quotes
#they both need to be either " or '
#if you have a contraction surround it in "
hereFirst = "Bryce & Kurt"
said = "said We won't have any vocabulary today'"
space = " "
print(hereFirst + space + said)

#Challenge Hi my name is sentence
name = "Barb" 
age = 23
hi = "Hi my name is "
ageIs = ", and my age is "
sentence = hi + name + ageIs + str(age)
print(sentence)














