#lists/array

myList = 1, 2, 3, 4, 5, 6, 7, 8, 9, 10
myOtherList = "a", "b", "c"
anotherList = "a", "b", "c", 1, 2, 3
shoppingList = ["water", "fruits", "cold cuts"]
shoppingList.append('chips')
shoppingList.append('oatmeal')
shoppingList.append('orange juice')
shoppingList.append('eggs')

print(myList[4])
print (anotherList[1])
print (shoppingList)
 
#Conditionals

#if(condition):
# do this
# else
#  do that

userInput = input("guess my name")

if(userInput == "Arjit"):
    print("Correct")
else:
    print("sorry")
