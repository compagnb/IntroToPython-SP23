import turtle

img = "invader1.gif"

wn = turtle.Screen()
wn.register_shape(img) 


barb = turtle.Turtle()
barb.shape(img)
