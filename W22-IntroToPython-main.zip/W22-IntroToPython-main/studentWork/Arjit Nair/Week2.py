#Variables!!!
#Can't have in a variable name:
#spaces - use camelCase or under_scores
#capital letters - these are reserved for other functions

name = "Arjit" #this is a string
age = 14 #this is an integer (whole number)
pie = 3.14 #this is called a float (decimal)
favPie = "Apple"
Intro = "Hi my name is"
ageIs = "and my age is"
school = "I go to New Hyde Park Memorial High school"
grade = "I am in 9th grade"
period = "." 

#Strings
#must be surrounded by quotes 
#they both need to be the either " or '
#if you have a contraction surround it in " 
hereFirst = "Bryce & Kurt"
said = "said we won't have any vocabulary today'"
space = " "
print (hereFirst + space + said)

print (Intro + space + name + space + ageIs + space + str(age) + period + space + school + period + space + grade + period)

sentence = Intro + space + name + space + ageIs + space + str(age) + period

print (sentence)
print (name * age) 















