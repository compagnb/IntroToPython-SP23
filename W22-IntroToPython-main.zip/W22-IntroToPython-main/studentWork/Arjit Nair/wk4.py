Python 2.7.15 (v2.7.15:ca079a3ea3, Apr 30 2018, 16:22:17) [MSC v.1500 32 bit (Intel)] on win32
Type "copyright", "credits" or "license()" for more information.
>>> 
============= RESTART: J:\W22-Python-AM\Arjit Nair\wk3hangman.py =============
pick a number60
sorry you are wrong, the correct number was 48
pick a number48
You win
>>> 
