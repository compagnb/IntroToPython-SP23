 #MadLib Game
#input() = take input from the user

#Madlib Game
#input() - take input from the user

number1 = input("Please enter a number.")
print(number1)
noun1 = input("Please eneter a noun.")
verb1 = input("Please eneter a verb.
adj1 = input("Please enter an adjective.")
number2 = input("Please eneter a number.")
place1 = input ("Please eneter a place.") 
firstName1 = input ("Please enter a name.") 
firstName2 = input ("Please eneter a name.") 
verbEd1 = input("Please enter a verb.") 
noun2 = input ("Pleasse enter a noun.") 
adj2 = input ("Please enter and adjective.") 
adj3 = input ("Please ennter an adjective.")
verbEd2 = input ("Please enter a verb.")
verbEd3 = input ("Please enter a verb.")
noun3 = input ("Please enter a noun.") 
verbEd4 = input ("Please enter a verb.") 
pluralNoun1 = input ("Please enter a plural noun.") 
verb2 = input ("Please enter a verb.") 
adverb1 = input ("Please enter an adverb.")
number4 = input ("Please enter a number.")

madLib = "first part" + number1 + "second part" + pluralNoun1 + "third part" + verb1 + "fourth part" + adj1 +
"fifth part" + noun1 + "sixth parth" + noun2 + "seventh part" + firstName1 + "eighth part"
+ verbEd1 + "ninth part" + noun3 "tenth part" + verbEd2 + "eleventh part" + noun4 + "twelfth part")
