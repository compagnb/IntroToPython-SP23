#list/array

myOtherList = "a", "b", "c"

print (myOtherList)
print (myOtherList ({2})
shoopingList = ["Chips", "Coke", "Micdonlads"]
shoopingList.append ("Minecraft")
print (shoppingList)
userInput = input ("guess my name")
if (userInput == "Javier"):
    print ("Correct")
    print ("close")
elif (userInput == "Mahdi") : 
else:
    print ("sorry")
      
    
    
