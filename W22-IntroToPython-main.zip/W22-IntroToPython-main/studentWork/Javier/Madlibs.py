#Madlib Game
#input () - take imput frrom the person

name1 = 'javier'
name2 = 'jon'
noun1 = 'viedo-games'
madlib = 'first part' + mane1 + 'second part'
