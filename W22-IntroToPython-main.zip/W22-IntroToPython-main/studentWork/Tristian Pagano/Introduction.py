name = "Tristian "
hi = "Hello, How are you today, "
print (hi + name)
