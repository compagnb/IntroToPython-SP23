#Madlib Game
#input = take input from user

space = (" ")
text1 = ("On July, ")
text2 = (" A ")
text3 = (" Ate Breakfast ")
number1 = input(" Please enter a number ")
noun1 = input(" Please enter a noun ")
#verb1 = input("Please enter a verb")
#number2 = input("Please enter a number")
#place = input("Please enter a place")
firstname1 = input(" Please enter a name ")
#firstname2 = input("Please enter a name")
#verb2 = input("Please enter a verb")
#verb3 = input("Please enter a verb")
#noun2 = input("Please enter a noun")
#verb4 = input("Please enter a verb")
#number3 = input("Please enter a number")
#verb5 = input("Please enter a verb")
#adjective = input("Please enter a adjective")

print (text1 + number1 + text2 + noun1 + space + firstname1 + text3)

input("Pausing Program, Press any button to end")





