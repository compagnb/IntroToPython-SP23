import random

numb = random.randint(1,100000000000000000)

shrek = input("pick number boi loser idot dumbo")

if(shrek == numb):
  print("ok you won, but why did you even try to do this you crazy @#$%")
else:
  print("ez loser bad dum idot you #$%&@#* sux, the correct number was " + str(numb))
  shrek = int(input("pick number boi loser idot dumbo"))
  
  bemean = input("wrong again @#$%&*@ so bye shut #$%&@")
  print(bemean)
  
