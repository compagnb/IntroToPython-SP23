#variables

#No variables with spaces
#spaces = camelCase or under_scores
#no capital letters because that is reserved for other functions
#uppercase must be in quotes

name = "Tristian" #is a string
age = "11" #this is an integer an integer is a whole number
pie = "3.141592653589793238462643" #this is called a float (decimal)
favpie = "Banana Peach"

#if you have a contraction surround it in quotes

hereFirst = "Bryce & Curt"
said = "said we won't have any vocabulary"
space = " "
#print ( hereFirst + space + said )

text = "Hi my name is"
text2 = "and I am"

#numbers need quotes
print (text + space + name + space + text2 + space + age)

#or do str mask

age2 = 11

print (text + space + name + space + text2 + space + str(age2))
