#madlib game
#input () - take input from the user
nuber1 = input ("please enter a number")
noun1 = input ("please enter a noun"
adj1 = input ("please enter a adjective")
number2 = input ("please enter a number")
place1 = input ("please enter a place")
firstname1 = input ("please enter a name")
firstname2 = input ("please enter a name"
verbed1 = input ("please enter a number")
noun2 = input ("please a noun")
adj2 = input ("please enter a adjective") 
adj3 = input ("please enter a adjective")
verbed2 = input ("please enter a verb-ed")
verbed3 = input ("please enter a verb-ed")
noun3 = input ("please enter a noun")
verbed4 = input ("please enter a verb-ed")
pluralnoun1 = input ("please enter a plrual noun")
verb2 = input ("please enter a verb")
averb1 = input ("please enter a adverb")
number2 = input ("please enter a number")
