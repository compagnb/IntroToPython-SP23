import random


numb = random.randint(1,5)
correctAnswer = False
unserInput = int(input("pick a number"))

while correctAnswer == False
    if(userInput == numb):
        print("You won,now get the fuck out of my face!")
        correctAnswer = True
      else:
          print("Sorry,your dumb ass bitch of a brain is nor fucking smart!Try again,Dumbass.)
                userInput = int(input("pick a number")






