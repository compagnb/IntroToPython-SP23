userinput = input("guess my name")
if userInput == ("larb"):
    print("Correct!")
else:(userInput == "nobody cares")
    print("sorry,we were talking about you right?")
else:
    print("Incorrect")
