import turtle

leo = turtle.Turtle()
leo.shape("turtle")

leo.penup()
leo.goto(-500,-375)
leo.pendown()

leo.speed(0)

while True:
    leo.forward(400)
    leo.left(90)
    leo.forward(100)
    leo.right(90)
    leo.forward(550)
    leo.left(90)
    leo.forward(15)
    leo.left(90)
    leo.forward(575)
    leo.left(90)
    leo.forward(100)
    leo.right(90)
    leo.forward(350)
    leo.right(90)
    leo.forward(15)
    leo.right(90)




