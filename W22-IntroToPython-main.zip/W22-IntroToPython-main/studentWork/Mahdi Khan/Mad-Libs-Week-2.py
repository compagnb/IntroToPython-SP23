#MadLibsGame
#NewCommand!: Input() - This command takes input from the user

adjective1 = input("Please enter a adjective.")
nationality1 = input("Please enter a nationality.")
person1 = input("Please enter a person.")
noun1 = input("Please enter a noun.")
adjective2 = input("Please enter a adjective")
noun2 = input("Please enter a new noun.")
adjective3 = input("Please enter a new adjective.")
adjective4 = input("Please enter a new adjective.")
pluralnoun1 = input("Please enter a plural noun.")
noun3 = input("Please enter a new noun.")
number1 = input("Please enter a number.")
shapes1 = input("Please enter a shape in plural form.")
food1 = input("Please enter a food.")
food2 = input("Please enter a new food.")
number2 = input("Please enter a new number.")


madlib = "Pizza was invented by a " + adjective1  + nationality1 + " chef named " + person1 + " To make a pizza, you need to take a lump of " + noun1 + ", and make a thin, round " + adjective2  + noun2 + " Then you cover it with " + adjective3 + " sauce, " + adjective4 + " cheese, and fresh chopped " + pluralnoun1 + " Next you have to bake it in a very hot " + noun3 + " When it is done, cut it into " + number1  + shapes1 + " Some kids like " + food1 + " pizza the best, but my favorite is the " + food2 + " pizza. If I could, I would eat pizza " + number2 + " times a day! "

print(madlib) 
