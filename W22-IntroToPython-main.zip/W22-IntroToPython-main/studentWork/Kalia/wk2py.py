print "Hi my name is + unknown,+ I am + 12 + years old"

name= "radndom"
age= "5+6"
hi= "Hi my name is"
ageIs= "And my age is"
sentence= hi + name + ageIs + str(age) 
print(sentence) 
