animal = input ("enter animal")
bodypart= input ("enter body part")
space = input (" ") 
print("one day bob saw a "+ animal + space + "and the" + "animal +ripped off his "+ bodypart + "now bob is scared of"+ animal)

