Python 2.7.16 (v2.7.16:413a49145e, Mar  4 2019, 01:37:19) [MSC v.1500 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> 
>>> adj1 = input('Enter an adjective:')
    color = input('Enter a color name:')
    thing = input('Enter a thing:')
    place = input('Enter a place:')
    person = input('Enter a person name:')
    adj2 = input('Enter an adjective:')
    insect= input('Enter an insect name:')
    food = input('Enter a food name:')
    verb = input('Enter a verb:')
    print('Last night I dreamed I was a' adj1 'butterfly with ' color 'splotches that looked like a bunch of ' thing ' .I flew to ' place ' with my bestfriend and ' person ' who was a ' adjective ' ' +insect ' .We ate some ' food ' when we got there and then decided to ' verb ' and the dream ended when I said-- lets ' verb '.')
