Python 2.7.16 (v2.7.16:413a49145e, Mar  4 2019, 01:37:19) [MSC v.1500 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>>name = "Deirdre" #this is a string
age = 13 #this is an integer (whole number)
pi = 3.14 #this is called floats (decimal)
favPie = "pumpkinpie"

#strings
#must be surrounded by same type of quote either " or '
#if you have a contraction around it in "
hereFirst = "Bryce & Kurt"
said = "said We won't have any vocabulary today'"
space " "
print(hereFirst + space + said)

#challenge 
name = "Dev"
age = 14
hi = "Hi my name is "
ageIs = ", and my age is "
sentence = hi + name + ageIs + str(age)
print(sentence)
