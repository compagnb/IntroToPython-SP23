Python 2.7.16 (v2.7.16:413a49145e, Mar  4 2019, 01:37:19) [MSC v.1500 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> 
import random

num = random.ramdint (0,0)
correctAnswer == False
userInput = int(input("pick a number")

while correctAnswer == False:
                if(userInputc == numb):
                print ("you win")
                correctAnswer = True

            else:
                print("sorry you were wrong the correct number w
