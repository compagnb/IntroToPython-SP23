#Madlib game
# input () - take imput from user

adjective1 = input("Please enter a Adjective.")
verb1 = input("Please enter a Verb.")
adjective2 = input("Please enter a Adjective.")
noun1N = input("Please enter a number Noun.")
pluralN1 = input("Please enter a Plural Noun.")
pluralN2 = input("Please enter a plural Noun.")
adjective3 = input("Please enter a Adjective.")
pluralN3 = input("Please enter a Plural Noun.")
adjective4 = input("Please enter a Adjective.")
pluralN4 = input("Please enter a Plural Noun.")
pluralN5 = input("Please enter a Plural Noun.")
pluralN6 = input("Please enter a Plural Noun.")
pluralN7 = input("Please enter a Plural Noun.")
verb2 = input("Please enter a Verb.")
pluralN8 = input("Please enter a Plural Noun.")
verb3 = input("Please enter a Plural Noun.")
pluralN9 = input("Please enter a Plural Noun.")
verb4 = input("Please enter a Plural Noun.")
verb5 = input("Please enter a Plural Noun.")


madlib = "Pyramids are " + adjective1 + "tombs where Egypitains " + verb1 + "their kings and adjective2 families. Some of them are "+noun1N+ "years old, each taking many" + pluralN1 + "to build. Each pyramid had" + pluralN2 + "inside and were" + adjective2 + "decorated with" + PluralN3 + "inside and were" + adjective3 + "decorated with" + pluralN4 + ". Some royal" + pluralN5 + "arranged to have" + pluralN6 + "and" + pluralN7 ++ verb2 + "with them when they died. Today, archaeologists and other" + pluralN8 + "continue to" + verb3 + "these ancient" + pluralN9 +"to" + verb4 + " about how people" + verb + "in the past."
print "madlib"
