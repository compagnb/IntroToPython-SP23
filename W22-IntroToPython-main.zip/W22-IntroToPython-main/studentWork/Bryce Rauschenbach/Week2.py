#Variables!!!
# can't have a varibles name:
#spaces - uses camelCase or under_scores\
#capital letters-these are reserved for other functions
#- to add anint to a string we have mask the int using str ()
name = "Bryce" #This is a string
number = 20 # this is an integer (whole number)
pie = 3.14 # this is called floats (desimal)
FavPie = "Bluebery"
#Strings must be sourrounded in "
hereFirst = "Bryce & Kurt"
said = "said 'we won't have any vocabulary today'"
space = " "
print (hereFirst + space + said)
#hi = " Hi my name is "
Name = "Bryce,"
#ageIs = " and my age is "
age = "10"
#sentence (hi + Name + ageIs + str(age))
#print (sentence)

Name * age


