import turtle

leo = turtle.Turtle()
leo.shape("turtle")
slides = 0

#leo.penup()
#leo.goto(100, 100)
#leo.pendown()
leo.color("blue")

#while slides < 4:
leo.left(100)
leo.right(200)
leo.left(100)
leo.forwards(90)
slides=slides+1



