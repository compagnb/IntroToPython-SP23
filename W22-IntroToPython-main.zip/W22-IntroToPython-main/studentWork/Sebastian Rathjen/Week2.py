#variables!!!
#Can't have in varible name
#spaces - use canelCase or under_scores\
#capital letters - these are reserved for other function
#to add a int to a string we have to mask the int using str()
name = "hello"
age = 23
pi = 3.14
favpie = "hotdog"

#strings
#must be surrpunded by quotes
#they both need to either " or '
hereFirst = "Bryce_&_Kurt"
said = "said We won't have any volculary today"
space = " "
print(hereFirst + space + said)


name = "sebastian"
age = 13
hi = "hi my name is "
ageIs = ", and my age is "
sentence = hi + name + ageIs + str(age) 
print (sentence)

name = "sebastian "
place = "and we will celerbrate it at my house "
hi = "Bdays is coming up "
would = "would you like to come? "
line = name + hi + place + would
print (line)
