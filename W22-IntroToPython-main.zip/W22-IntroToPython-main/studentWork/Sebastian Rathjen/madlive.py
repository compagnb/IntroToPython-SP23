#madlive game
#input () - take input from the user




dangerousanmaL1 = input("name a dangerous animal. ")
bodypart = input("name a body part")
madlib = "ond day, bob saw a " + dangerousanmaL1 + "and it ripped off his " + bodypart + "and bob hates" + dangerousanmaL1 + "now" 


